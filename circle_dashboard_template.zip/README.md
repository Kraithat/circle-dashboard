# Circle Condo Damage Dashboard

แดชบอร์ดสำหรับรายงานและวิเคราะห์ความเสียหายจากเหตุแผ่นดินไหว ที่เกิดขึ้นในโครงการเซอร์เคิล คอนโดมิเนียม  
สร้างขึ้นด้วย **Streamlit + Plotly** พร้อมข้อมูลจากแบบสอบถามจริง

## วิธีใช้งานบน Streamlit Cloud

1. Fork หรืออัปโหลดโปรเจกต์นี้ขึ้น GitHub
2. ไปที่ [https://streamlit.io/cloud](https://streamlit.io/cloud)
3. เลือก "Deploy from GitHub" แล้วใส่ลิงก์ repo นี้
4. เริ่มใช้งานและแชร์ลิงก์ได้ทันที!